---
categories:
  - id: 'office'
    name: '办公工具'
    icon: '💼'
    sort: 1

  - id: 'books'
    name: '教育平台'
    icon: 'icons/教育平台.svg'
    sort: 2

  - id: 'custom_1774756924959'
    name: '高伟达'
    icon: 'icons/高伟达.svg'
    sort: 2

  - id: 'tech'
    name: '编程'
    icon: '💻'
    sort: 4

  - id: 'news'
    name: '新闻资讯'
    icon: '📰'
    sort: 4

  - id: 'shopping'
    name: '购物电商'
    icon: '🛒'
    sort: 5

  - id: 'social'
    name: '社交'
    icon: '🎯'
    sort: 6

  - id: 'custom_1773890047269'
    name: '人工智能'
    icon: '💡'
    sort: 8

  - id: 'travel'
    name: '旅游出行'
    icon: '✈️'
    sort: 11

  - id: 'game'
    name: '游戏'
    icon: '🎮'
    sort: 13

  - id: 'web3'
    name: 'web3'
    icon: 'icons/高伟达.svg'
    sort: 20

  - id: 'custom_1790770591238'
    name: '官网'
    icon: 'icons/官网.svg'
    sort: 21

  - id: 'custom_1791869874653'
    name: '开源项目'
    icon: 'icons/开源项目.svg'
    sort: 22

  - id: 'custom_1792421177782'
    name: '智能助手'
    icon: ''
    sort: 23

searchEngines:
  - id: 'quark'
    name: '夸克'
    url: 'https://quark.cn/s?query='
    isDefault: false
    sort: 6

  - id: 'github'
    name: 'GitHub'
    url: 'https://github.com/search?q='
    isDefault: false
    sort: 9

countdowns:
  - id: 'cd_1785544658582'
    name: '高考'
    endDateTime: '2027-06-06T00:00'
    repeat:
      type: yearly
    category: '倒计时'
    color: '#3b82f6'
    sortOrder: 2
    createdAt: '2026-08-01T23:10:09.332Z'
    updatedAt: '2026-08-23T15:33:36.218Z'

  - id: 'cd_1785842998317'
    name: '司泽景生日'
    endDateTime: '2026-03-20T09:00'
    repeat:
      type: yearly
    category: '倒计时'
    color: '#f97316'
    lastRemindedAt: '2026-03-20 09:00'
    sortOrder: 3
    showOnDisplay: false
    createdAt: '2026-08-04T11:29:58.317Z'
    updatedAt: '2026-08-23T15:34:30.625Z'

  - id: 'cd_1785880610706'
    name: '上班'
    endDateTime: '2026-08-05T07:30'
    repeat:
      type: weekly
      daysOfWeek:
        - 1
        - 2
        - 3
        - 4
        - 5
    category: 'work'
    color: '#463535'
    lastRemindedAt: '2026-10-29 07:30'
    sortOrder: 1
    emailReminder: true
    createdAt: '2026-08-04T21:56:50.706Z'
    updatedAt: '2026-10-28T23:30:04.907Z'

  - id: 'cd_1785925052497'
    name: '司福江生日'
    endDateTime: '1992-05-01T09:00'
    repeat:
      type: yearly
    category: '倒计时'
    color: '#f97316'
    lastRemindedAt: '2026-05-01 09:00'
    sortOrder: 4
    showOnDisplay: false
    createdAt: '2026-08-05T10:17:32.497Z'
    updatedAt: '2026-08-23T15:34:42.203Z'

  - id: 'cd_1786057135634'
    name: '早晨跑步'
    endDateTime: '2026-08-07T07:00'
    repeat:
      type: weekly
      daysOfWeek:
        - 6
        - 7
    category: 'exercise'
    color: '#a855f7'
    lastRemindedAt: '2026-10-25 07:00'
    sortOrder: 5
    showOnDisplay: false
    createdAt: '2026-08-06T22:58:55.634Z'
    updatedAt: '2026-10-25T03:32:20.236Z'

  - id: 'cd_1786057247339'
    name: '打扫卫生'
    endDateTime: '2026-08-07T21:00'
    repeat:
      type: weekly
      daysOfWeek:
        - 2
        - 4
        - 7
    category: 'life'
    color: '#eab308'
    lastRemindedAt: '2026-10-27 21:00'
    sortOrder: 6
    showOnDisplay: false
    createdAt: '2026-08-06T23:00:47.339Z'
    updatedAt: '2026-10-27T13:00:35.381Z'

  - id: 'cd_1786142581264'
    name: '傍晚跑步'
    endDateTime: '2026-08-08T19:00'
    repeat:
      type: weekly
      daysOfWeek:
        - 1
        - 2
        - 3
        - 4
        - 5
    category: 'exercise'
    color: '#3b82f6'
    lastRemindedAt: '2026-10-28 19:00'
    sortOrder: 7
    showOnDisplay: false
    createdAt: '2026-08-07T22:43:01.264Z'
    updatedAt: '2026-10-28T13:00:50.836Z'

  - id: 'cd_1786142661560'
    name: '周一至周五起床'
    endDateTime: '2026-08-08T06:30'
    repeat:
      type: weekly
      daysOfWeek:
        - 1
        - 2
        - 3
        - 4
        - 5
    category: 'sleep'
    color: '#3b82f6'
    lastRemindedAt: '2026-10-29 06:30'
    sortOrder: 8
    showOnDisplay: false
    createdAt: '2026-08-07T22:44:21.560Z'
    updatedAt: '2026-10-28T22:30:36.135Z'

  - id: 'cd_1786142791224'
    name: '周末起床'
    endDateTime: '2026-08-08T06:45'
    repeat:
      type: weekly
      daysOfWeek:
        - 6
        - 7
    category: 'sleep'
    color: '#a855f7'
    lastRemindedAt: '2026-10-25 06:45'
    sortOrder: 9
    showOnDisplay: false
    createdAt: '2026-08-07T22:46:31.224Z'
    updatedAt: '2026-10-25T03:32:20.392Z'

  - id: 'cd_1786143073136'
    name: '送娃幼儿园'
    endDateTime: '2026-08-08T07:30'
    repeat:
      type: weekly
      daysOfWeek:
        - 1
        - 2
        - 3
        - 4
        - 5
    category: 'life'
    color: '#3b82f6'
    lastRemindedAt: '2026-10-29 07:30'
    sortOrder: 10
    showOnDisplay: false
    createdAt: '2026-08-07T22:51:13.136Z'
    updatedAt: '2026-10-28T23:30:08.879Z'

  - id: 'cd_1786143251584'
    name: '周一至周五早餐'
    endDateTime: '2026-08-08T07:00'
    repeat:
      type: weekly
      daysOfWeek:
        - 1
        - 2
        - 3
        - 4
        - 5
    category: 'diet'
    color: '#f97316'
    lastRemindedAt: '2026-10-29 07:00'
    sortOrder: 11
    showOnDisplay: false
    createdAt: '2026-08-07T22:54:11.584Z'
    updatedAt: '2026-10-28T23:03:07.109Z'

  - id: 'cd_1786143345673'
    name: '周六周日早餐'
    endDateTime: '2026-08-08T08:00'
    repeat:
      type: weekly
      daysOfWeek:
        - 6
        - 7
    category: 'diet'
    color: '#eab308'
    lastRemindedAt: '2026-10-25 08:00'
    sortOrder: 12
    showOnDisplay: false
    createdAt: '2026-08-07T22:55:45.673Z'
    updatedAt: '2026-10-25T03:32:20.415Z'

  - id: 'cd_1786143572929'
    name: '睡觉'
    endDateTime: '2026-08-08T22:00'
    repeat:
      type: daily
    category: 'sleep'
    color: '#3b82f6'
    lastRemindedAt: '2026-10-28 22:00'
    sortOrder: 13
    showOnDisplay: false
    emailReminder: true
    createdAt: '2026-08-07T22:59:32.929Z'
    updatedAt: '2026-10-28T14:00:35.378Z'

  - id: 'cd_1786143661761'
    name: '晚餐'
    endDateTime: '2026-08-08T18:40'
    repeat:
      type: daily
    category: 'diet'
    color: '#22c55e'
    lastRemindedAt: '2026-10-28 18:40'
    sortOrder: 14
    showOnDisplay: false
    createdAt: '2026-08-07T23:01:01.761Z'
    updatedAt: '2026-10-28T13:00:50.861Z'

  - id: 'cd_1786235144746'
    name: '下班'
    endDateTime: '2026-08-09T17:50'
    repeat:
      type: weekly
      daysOfWeek:
        - 1
        - 2
        - 3
        - 4
        - 5
    category: 'work'
    color: '#3b82f6'
    lastRemindedAt: '2026-10-28 17:50'
    sortOrder: 15
    emailReminder: true
    createdAt: '2026-08-09T00:25:44.746Z'
    updatedAt: '2026-10-28T13:00:50.862Z'

  - id: 'cd_1786235295001'
    name: '薪资'
    endDateTime: '2026-08-01T17:30'
    repeat:
      type: monthly
      dayOfMonth: 1
    category: '倒计时'
    color: '#ec4899'
    lastRemindedAt: '2026-10-01 17:30'
    sortOrder: 16
    showOnDisplay: false
    createdAt: '2026-08-09T00:28:15.001Z'
    updatedAt: '2026-10-02T12:49:58.281Z'

  - id: 'cd_1788323230490'
    name: '填写工时'
    endDateTime: '2026-09-02T09:30'
    repeat:
      type: monthly
      dayOfMonth: 21
    category: 'life'
    color: '#3b82f6'
    lastRemindedAt: '2026-10-21 09:30'
    sortOrder: 18
    showOnDisplay: false
    emailReminder: true
    createdAt: '2026-09-02T04:27:10.490Z'
    updatedAt: '2026-10-22T08:06:00.874Z'

  - id: 'cd_1789907987964'
    name: '100岁倒计时'
    endDateTime: '2092-05-01T00:00'
    category: '倒计时'
    color: '#3b82f6'
    sortOrder: 19
    createdAt: '2026-09-20T12:39:47.964Z'
    updatedAt: '2026-09-20T12:39:47.964Z'

sites:
  - name: '哔哩哔哩'
    url: 'https://www.bilibili.com'
    description: '弹幕视频网站，提供动画、游戏、科技等领域的视频内容'
    category: 'video'
    tags: ['视频']
    icon: 'icons/哔哩哔哩.svg'
    sort: 132
    createdAt: '2026-03-19T07:53:05.443Z'

  - name: 'DeepSeek'
    url: 'https://deepseek.com'
    description: '深度求索推出的AI大模型，提供智能对话、编程辅助、深度推理等服务'
    category: 'office'
    tags: ['大模型']
    icon: '/icons/deepseek.svg'
    sort: 127
    createdAt: '2026-03-19T03:15:33.215Z'

  - name: '公众号'
    url: 'https://mp.weixin.qq.com/'
    description: '公众号'
    category: 'social'
    tags: ['社交']
    icon: 'icons/公众号.svg'
    sort: 119
    createdAt: '2026-09-11T11:13:23.775Z'

  - name: 'Iconfont'
    url: 'https://www.iconfont.cn/'
    description: '阿里巴巴旗下矢量图标库，提供图标搜索、下载和管理服务'
    category: 'tech'
    tags: ['图标']
    icon: 'icons/Iconfont.svg'
    sort: 113
    createdAt: '2026-03-31T06:27:04.403Z'

  - name: 'Element'
    url: 'https://element.eleme.cn'
    description: '饿了么开源的Vue 2.0桌面端组件库，面向开发者、设计师和产品经理'
    category: 'tech'
    tags: ['前端']
    icon: 'icons/Element.svg'
    sort: 108
    createdAt: '2026-04-17T00:38:05.573Z'

  - name: '飞书'
    url: 'https://www.feishu.cn'
    description: '将团队、工具和工作流程整合于一处——助力高效工作、降低成本、保持同步。'
    category: 'office'
    tags: ['文档']
    icon: 'icons/飞书.ico'
    sort: 108
    createdAt: '2026-03-29T03:23:59.609Z'

  - name: '码云(gitee)'
    url: 'https://gitee.com'
    description: '面向企业提供一站式研发管理解决方案'
    category: 'tech'
    tags: ['项目托管']
    icon: 'icons/码云gitee.ico'
    sort: 107
    createdAt: '2026-03-19T08:06:02.081Z'

  - name: '免费桌面屏保合集'
    url: 'https://webscreen.net/zh'
    description: '18 款免费动态屏保，含桌面时钟、水族馆、贪吃蛇、极光、相册轮播、文字滚动等，可自定义效果，兼具实用与趣味。'
    category: 'office'
    tags: ['屏保', '桌面']
    icon: 'icons/免费桌面屏保合集.svg'
    sort: 106
    createdAt: '2026-09-15T12:31:27.000Z'

  - name: 'QQ邮箱'
    url: 'https://mail.qq.com'
    description: '腾讯QQ邮箱服务，提供邮件收发和管理功能'
    category: 'office'
    tags: []
    icon: 'icons/QQ邮箱.svg'
    sort: 106
    createdAt: '2026-03-29T13:26:52.301Z'

  - name: '史前动物博物馆'
    url: 'https://leon-made-this.work/museum/zh-CN/'
    description: '面向 2–6 岁孩子的免费 3D 恐龙与古生物科普网站，几十种复原动态模型，附家长资料方便讲解。'
    category: 'game'
    tags: ['科普', '儿童']
    icon: 'icons/史前动物博物馆.svg'
    sort: 105
    createdAt: '2026-09-15T12:31:29.000Z'

  - name: '阿里云盘'
    url: 'https://www.alipan.com'
    description: '阿里云旗下网盘服务，提供文件存储、备份和分享功能'
    category: 'office'
    tags: ['网盘']
    icon: 'icons/阿里云盘.svg'
    sort: 104
    createdAt: '2026-03-20T08:39:55.352Z'

  - name: 'pudone'
    url: 'https://pudone.com'
    description: '功能超丰富的在线工具百宝箱，集合 200+ 实用小工具，涵盖办公、媒体、开发、协作、生活、转换、趣味等。页面简洁无广告，全部免费使用。'
    category: 'tech'
    tags: ['工具', '在线']
    icon: 'icons/pudone.png'
    sort: 104
    createdAt: '2026-09-15T12:31:24.000Z'

  - name: 'DeepSeekWebUi'
    url: 'http://127.0.0.1:3080'
    description: 'DeepSeek Harness（dsh）是由 DeepSeek AI 开发的开源 agent harness（智能体框架）。'
    category: 'tech'
    tags: ['工具']
    icon: 'icons/DeepSeekWebUi.svg'
    sort: 103
    createdAt: '2026-08-16T00:52:51.833Z'

  - name: 'Poxel.io'
    url: 'https://poxel.io'
    description: '3D 像素风多人在线射击游戏，几十款地图武器，混战/团队/据点多种模式，网页即玩，WASD+鼠标操作，约 6 分钟一盘。'
    category: 'game'
    tags: ['游戏', '休闲']
    icon: 'icons/Poxel.io.svg'
    sort: 102
    createdAt: '2026-09-15T12:31:26.000Z'

  - name: 'deepseek-harness'
    url: 'https://www.deepseek.com/harness/'
    description: ''
    category: 'tech'
    tags: ['工具']
    icon: '/icons/deepseek.svg'
    sort: 102
    createdAt: '2026-08-14T20:08:42.807Z'

  - name: '不空'
    url: 'https://bhtq.cn'
    description: '钓鱼天气与鱼情记录面向钓鱼爱好者的鱼情查询工具，选城市与鱼种即可结合天气算出鱼活跃度，给出最佳出钓时段与鱼情评分。'
    category: 'travel'
    tags: ['钓鱼', '天气', '社交']
    icon: 'icons/不空.svg'
    sort: 101
    createdAt: '2026-09-15T12:31:28.000Z'

  - name: 'PS网页版'
    url: 'https://s.gd-share.cn/4qf7'
    description: '网页版 Photoshop 最佳替代工具，支持 PSD/PNG/JPG 导入导出，无需安装、浏览器直接打开使用，修图做海报改素材很方便。'
    category: 'office'
    tags: ['工具', '修图']
    icon: 'icons/PS网页版.svg'
    sort: 100
    createdAt: '2026-09-15T12:31:25.000Z'

  - name: 'Cloudflare'
    url: 'https://www.cloudflare.com/'
    description: 'Cloudflare 是一家业界领先的全球连通云公司，其使命是帮助构建更好的互联网。它通过一个庞大的全球网络，为各种规模的组织提供网站安全管理、性能优化及相关的技术支持，旨在让接入互联网的一切都更安全、快速和可靠。'
    category: 'tech'
    tags: ['云服务', 'CDN']
    icon: 'icons/Cloudflare.svg'
    sort: 99
    createdAt: '2026-09-09T15:43:56.000Z'

  - name: 'WallpaperHub'
    url: 'https://www.wallpaperhub.app'
    description: '微软系高清壁纸资源站，汇集 Bing 每日壁纸与 Windows 原生主题壁纸，无水印超清原图可直接下载。'
    category: 'office'
    tags: ['壁纸', '桌面']
    icon: ''
    sort: 99
    createdAt: '2026-09-15T12:31:30.000Z'

  - name: 'DSH插件市场'
    url: 'https://dshopen.org/zh/'
    description: 'DeepSeek Harness 的社区插件索引与每日推荐。10 月 15 日起 DSH 支持插件市场，复制下面的地址粘贴到「发现」，就能直接浏览、安装几百个社区插件。'
    category: 'custom_1773890047269'
    tags: []
    icon: ''
    sort: 13
    createdAt: '2026-10-26T08:40:36.216Z'

  - name: 'GitHub'
    url: 'https://github.com'
    description: '全球最大的代码托管平台，提供 Git 仓库托管和协作开发工具'
    category: 'tech'
    tags: ['项目托管']
    icon: 'icons/GitHub.svg'
    sort: 12
    createdAt: '2024-01-01T00:00:00.000Z'

  - name: 'opencode'
    url: 'https://opencode.ai'
    description: 'OpenCode 是一个开源代理，可帮助您在终端、集成开发环境或桌面端编写代码。'
    category: 'custom_1791869874653'
    tags: ['工具']
    icon: 'icons/opencode.ico'
    sort: 11
    createdAt: '2026-03-29T04:30:15.015Z'

  - name: 'OpenClaw'
    url: 'https://docs.openclaw.ai/zh-CN'
    description: 'OpenClaw官方文档，AI智能体网关，支持WhatsApp、Telegram、Discord等多平台消息接入'
    category: 'custom_1792421177782'
    tags: ['智能体']
    icon: 'icons/OpenClaw.svg'
    sort: 8
    createdAt: '2026-03-28T08:07:39.719Z'

  - name: '抖音'
    url: 'https://www.douyin.com'
    description: '字节跳动旗下短视频平台，提供短视频创作和分享服务'
    category: 'video'
    tags: ['视频']
    icon: 'icons/抖音.svg'
    sort: 8
    createdAt: '2026-03-20T08:37:54.510Z'

  - name: '国家高等教育智慧教育平台'
    url: 'https://higher.smartedu.cn/'
    description: '适合人群： 大学生、考研党、职场人士平台亮点： 汇集了超过14.5万门名校的 慕课 ，包括大量985/211大学的公开课，覆盖理学、工学、文学、医学等13个学科。对于想提升学历或职场技能的人来说是宝藏资源。'
    category: 'books'
    tags: ['大学，考研']
    icon: 'icons/国家高等教育智慧教育平台.svg'
    sort: 8
    createdAt: '2026-10-16T06:19:34.934Z'

  - name: '国家职业教育智慧教育平台'
    url: 'https://vocational.smartedu.cn/'
    description: '适合人群： 职校学生、想转行或学习新技能的人平台亮点： 专注于职业技能培训，内容涵盖智能制造、新能源汽车、护理养老、电商运营等多个热门行业，提供虚拟仿真实训和实操性强的课程。'
    category: 'books'
    tags: ['职校']
    icon: 'icons/国家职业教育智慧教育平台.svg'
    sort: 8
    createdAt: '2026-10-16T06:20:21.926Z'

  - name: 'Trae'
    url: 'https://www.trae.com.cn'
    description: '字节跳动推出的AI原生IDE，支持AI编程、智能体协作和自然语言开发'
    category: 'tech'
    tags: ['工具']
    icon: 'icons/Trae.ico'
    sort: 7
    createdAt: '2026-03-20T08:45:12.609Z'

  - name: '国家开放大学'
    url: 'https://www.ouchn.edu.cn/'
    description: '适合人群：希望继续教育的上班族、中老年人平台亮点： 提供学历提升、职业技能和兴趣生活类课程，比如书法、广场舞、中医养生等，学习节奏舒缓，对零基础用户很友好。'
    category: 'books'
    tags: ['上班族，中老年人']
    icon: 'icons/国家开放大学.svg'
    sort: 7
    createdAt: '2026-10-16T06:21:42.357Z'

  - name: '豆包'
    url: 'https://www.doubao.com'
    description: '字节跳动旗下AI智能助手，提供对话、写作、编程等AI能力'
    category: 'custom_1773890047269'
    tags: ['大模型', '智能体']
    icon: 'icons/豆包.svg'
    sort: 6
    createdAt: '2026-03-29T09:51:27.674Z'

  - name: '智谱'
    url: 'https://www.zhipuai.cn'
    description: '智谱AI推出的大模型平台，提供GLM系列模型API和智能体服务'
    category: 'custom_1773890047269'
    tags: ['大模型']
    icon: 'icons/智谱.svg'
    sort: 6
    createdAt: '2026-03-20T08:42:36.444Z'

  - name: '硅基流动'
    url: 'https://siliconflow.cn'
    description: 'AI推理云服务平台，提供多种开源大模型API、模型加速和私有化部署服务'
    category: 'custom_1773890047269'
    tags: ['开发平台']
    icon: 'icons/硅基流动.svg'
    sort: 6
    createdAt: '2026-03-29T09:59:44.564Z'

  - name: '小云雀'
    url: 'https://xyq.jianying.com'
    description: ''
    category: 'custom_1773890047269'
    tags: []
    icon: 'icons/小云雀.svg'
    sort: 6
    createdAt: '2026-08-12T13:47:56.892Z'

  - name: 'ClawHub'
    url: 'https://clawhub.ai/'
    description: 'AI智能体技能和插件市场平台，可发布、搜索和管理Agent技能包'
    category: 'custom_1773890047269'
    tags: ['技能']
    icon: 'icons/ClawHub.svg'
    sort: 5
    createdAt: '2026-03-20T01:08:57.076Z'

  - name: '阿里云'
    url: 'https://www.aliyun.com'
    description: '阿里巴巴旗下云计算服务平台，提供云服务器、数据库、AI等全套云服务'
    category: 'tech'
    tags: []
    icon: 'icons/阿里云.svg'
    sort: 5
    createdAt: '2026-03-20T08:36:02.069Z'

  - name: 'EmailJs'
    url: 'https://www.emailjs.com/'
    description: 'EmailJS 是一项专为前端开发者设计的邮件发送服务。它的核心价值在于，让你能够仅通过客户端的 JavaScript 代码直接发送邮件，而无需搭建和维护任何后端服务器'
    category: 'tech'
    tags: ['工具']
    icon: ''
    sort: 5
    createdAt: '2026-08-16T13:44:44.479Z'

  - name: '中国数字科技馆'
    url: 'https://www.cdstm.cn/'
    description: '适合人群： 对科学感兴趣的所有人平台亮点： 由中国科协主办，提供天文地理、人工智能、航天科技等领域的趣味科学动画和线上实验，非常适合科普启蒙。'
    category: 'books'
    tags: []
    icon: 'icons/中国数字科技馆.svg'
    sort: 5
    createdAt: '2026-10-16T06:20:59.961Z'

  - name: 'obsidian'
    url: 'https://obsidian.md'
    description: '基于本地Markdown文件的知识管理和笔记工具，数据完全存储在本地设备'
    category: 'office'
    tags: []
    icon: 'icons/obsidian.svg'
    sort: 4
    createdAt: '2026-04-02T01:38:42.680Z'

  - name: 'Spring'
    url: 'https://spring.io'
    description: 'Spring Framework、Spring Boot、Spring Cloud等生态的官方手册。'
    category: 'tech'
    tags: []
    icon: 'icons/Spring.svg'
    sort: 4
    createdAt: '2026-03-20T00:31:56.464Z'

  - name: '网易UU远程'
    url: 'https://uuyc.163.com/'
    description: '真4K、真免费、真好用 网易资深团队出品，超低延迟多端远程控制。'
    category: 'office'
    tags: ['工具']
    icon: 'icons/网易UU远程.png'
    sort: 4
    createdAt: '2026-08-17T12:24:49.842Z'

  - name: 'Halo'
    url: 'https://www.halo.run'
    description: '强大易用的开源建站工具，支持博客、企业官网、知识库等多种站点搭建'
    category: 'tech'
    tags: ['工具']
    icon: 'https://www.halo.run/favicon.ico'
    sort: 4
    createdAt: '2026-03-19T07:48:32.215Z'

  - name: '学习强国'
    url: 'https://www.xuexi.cn/'
    description: '适合人群： 全年龄段用户平台亮点： 虽然名字听起来很严肃，但它其实是一个巨大的学习资源库。除了时政新闻，还有适合孩子的动画科普、适合学生的作文素材、适合上班族的职场技能课程，以及适合中老年人的养生、戏曲和智能手机教程。'
    category: 'books'
    tags: ['公务员']
    icon: 'icons/学习强国.svg'
    sort: 4
    createdAt: '2026-10-16T06:19:03.500Z'

  - name: '俄罗斯方块'
    url: '/games/tetris/index.html'
    description: '经典俄罗斯方块游戏'
    category: 'game'
    tags: ['游戏']
    icon: '/icons/elsfk.svg'
    sort: 3
    createdAt: '2026-10-01T16:35:49.975Z'

  - name: 'Cron表达式生成器'
    url: '/games/cron-generator/index.html'
    description: 'Cron定时任务表达式生成工具'
    category: 'office'
    tags: ['游戏', '工具']
    icon: '/icons/cron.svg'
    sort: 3
    createdAt: '2026-10-01T16:35:49.975Z'

  - name: 'JetBrains'
    url: 'https://www.jetbrains.com'
    description: '为每种语言和技术栈量身定制的 IDE'
    category: 'tech'
    tags: ['工具']
    icon: 'icons/JetBrains.ico'
    sort: 3
    createdAt: '2026-03-20T08:33:42.380Z'

  - name: '国家中小学智慧教育平台'
    url: 'https://basic.smartedu.cn/'
    description: '合适群体： 小学、初中、高中生及家长平台特点： 这是教育部官方平台，完全免费，用好他们，可以省下大几千补课费。覆盖了小学到高中所有年级和学科的课程资源。它的全科都是顶级名师，从小学到高三，语数英物化生史地政全学科全覆盖，教材版本最全，全国名师免费当家教。你可以找到全国特级教师录制的同步课程，用于课前预习或课后复习。平台还包含德育、体育、美育、课后服务、家庭教育等多个板块，所有资源都免费使用。实用技巧： 在这个平台上可以直接下载电子课本。有用户分享了详细的下载方法，可以帮你把教材保存为PDF文件，方便随时查看。'
    category: 'books'
    tags: ['小学，初中，高中']
    icon: 'icons/国家中小学智慧教育平台.svg'
    sort: 3
    createdAt: '2026-10-16T06:18:26.752Z'

  - name: 'Postman 指南'
    url: '/games/postman/index.html'
    description: 'Postman 指南 · 从入门到精通'
    category: 'office'
    tags: ['游戏', '工具']
    icon: '/icons/postman.svg'
    sort: 2
    createdAt: '2026-10-01T16:35:49.975Z'

  - name: '京东'
    url: 'https://www.jd.com'
    description: '京东综合购物平台，提供电子产品、日用品等在线购物服务'
    category: 'shopping'
    tags: ['购物']
    icon: 'icons/京东.svg'
    sort: 2
    createdAt: '2026-03-19T07:42:14.155Z'

  - name: '百度网盘'
    url: 'https://pan.baidu.com'
    description: '百度旗下网盘服务，提供文件存储、备份和分享功能'
    category: 'office'
    tags: ['网盘']
    icon: 'icons/百度网盘.svg'
    sort: 2
    createdAt: '2026-03-19T08:52:57.850Z'

  - name: 'Maven Central'
    url: 'https://central.sonatype.com'
    description: 'Java最常用的依赖仓库'
    category: 'tech'
    tags: []
    icon: 'icons/Maven_Central.svg'
    sort: 2
    createdAt: '2026-03-20T00:33:43.089Z'

  - name: 'nacos'
    url: 'https://nacos.io'
    description: '阿里开源的动态服务发现、配置管理和服务管理平台'
    category: 'tech'
    tags: ['工具']
    icon: 'icons/nacos.svg'
    sort: 2
    createdAt: '2026-03-29T13:37:08.824Z'

  - name: 'seata'
    url: 'https://seata.apache.org/zh-cn'
    description: '阿里开源的分布式事务解决方案，支持AT、TCC、SAGA、XA等模式'
    category: 'tech'
    tags: ['工具']
    icon: 'icons/seata.ico'
    sort: 2
    createdAt: '2026-03-29T13:38:22.107Z'

  - name: '高伟达邮箱'
    url: 'http://mail.git.com.cn'
    description: '高伟达公司内部企业邮箱服务'
    category: 'custom_1774756924959'
    tags: []
    icon: 'icons/高伟达邮箱.svg'
    sort: 2
    createdAt: '2026-03-29T04:06:09.137Z'

  - name: 'oh-my-opencode'
    url: 'https://github.com/code-yeongyu/oh-my-opencode'
    description: '面向复杂代码库的多智能体AI编程框架，支持多AI代理协作完成编码任务'
    category: 'custom_1791869874653'
    tags: ['源码']
    icon: 'icons/GitHub.svg'
    sort: 2
    createdAt: '2026-03-30T02:44:02.386Z'

  - name: 'qoder'
    url: 'https://qoder.com'
    description: 'Qoder is a next-generation AI programming platform that offers intelligent code completion, AI conversational programming, and automatic code generation. It supports mainstream IDEs like VS Code and JetBrains. Download for free.'
    category: 'custom_1792421177782'
    tags: ['工具']
    icon: 'icons/qoder.svg'
    sort: 2
    createdAt: '2026-08-06T04:41:22.480Z'

  - name: '坚果云'
    url: 'https://www.jianguoyun.com/'
    description: '实时自动同步网盘'
    category: 'office'
    tags: ['网盘']
    icon: 'icons/坚果云.svg'
    sort: 2
    createdAt: '2026-09-04T09:31:16.916Z'

  - name: '通义千问'
    url: 'https://tongyi.aliyun.com'
    description: '阿里巴巴推出的大模型平台，提供千问系列模型API和多模态能力'
    category: 'custom_1773890047269'
    tags: ['大模型']
    icon: 'icons/通义千问.svg'
    sort: 2
    createdAt: '2026-03-29T09:47:27.178Z'

  - name: 'Element'
    url: 'https://element.eleme.cn/#/zh-CN'
    description: '饿了么开源的Vue 2.0桌面端组件库，面向开发者、设计师和产品经理'
    category: 'tech'
    tags: ['前端']
    icon: 'icons/Element.svg'
    sort: 2
    createdAt: '2026-04-17T00:36:19.028Z'

  - name: 'arthas'
    url: 'https://arthas.aliyun.com'
    description: '阿里开源的Java线上诊断工具，支持运行时监控、方法追踪和问题排查'
    category: 'tech'
    tags: ['工具']
    icon: 'icons/arthas.ico'
    sort: 2
    createdAt: '2026-03-29T12:59:24.984Z'

  - name: '学信网'
    url: 'https://www.chsi.com.cn/'
    description: '教育部学历查询网站、教育部高校招生阳光工程指定网站、全国硕士研究生招生报名和调剂指定网站'
    category: 'custom_1790770591238'
    tags: []
    icon: 'icons/学信网.svg'
    sort: 2
    createdAt: '2026-10-12T02:50:25.303Z'

  - name: 'm3e-canvas'
    url: 'https://lnkiai.github.io/m3e-canvas/'
    description: 'M3E Canvas 是一个开源的浏览器端 UI 设计工具，核心目标是让用户通过拖拽方式快速搭建 Material 3 Expressive 风格的应用界面，并自动生成结构化的自然语言提示词，直接用于 AI 编程工具（如 Claude Code、Codex、Cursor 等）进行后续开发'
    category: 'tech'
    tags: []
    icon: 'icons/m3e-canvas.svg'
    sort: 2
    createdAt: '2026-10-13T06:12:47.442Z'

  - name: '百度'
    url: 'https://www.baidu.com'
    description: '搜索引擎'
    category: 'office'
    tags: []
    icon: 'icons/百度.svg'
    sort: 1
    createdAt: '2026-10-04T11:23:05.468Z'

  - name: '中国铁路12306'
    url: 'https://www.12306.cn'
    description: '中国铁路12306'
    category: 'travel'
    tags: []
    icon: 'icons/中国铁路12306.svg'
    sort: 1
    createdAt: '2026-03-29T14:01:00.658Z'

  - name: 'TypeScript'
    url: 'https://www.typescriptlang.org'
    description: 'JavaScript 的超集，提供类型系统'
    category: 'tech'
    tags: ['前端']
    icon: 'icons/TypeScript.svg'
    sort: 1
    createdAt: '2024-01-06T00:00:00.000Z'

  - name: 'CSS-Tricks'
    url: 'https://css-tricks.com'
    description: 'CSS 技巧和教程网站，前端开发者必看'
    category: 'tech'
    tags: ['前端']
    icon: 'https://css-tricks.com/favicon.ico'
    sort: 1
    createdAt: '2024-01-08T00:00:00.000Z'

  - name: 'Apache SkyWalking'
    url: 'https://skywalking.apache.org'
    description: '开源APM应用性能监控系统，提供分布式链路追踪、服务拓扑分析和日志管理'
    category: 'tech'
    tags: ['工具']
    icon: 'icons/Apache_SkyWalking.ico'
    sort: 1
    createdAt: '2026-03-20T08:23:14.855Z'

  - name: 'OceanBase'
    url: 'https://www.oceanbase.com'
    description: '蚂蚁集团自研的分布式数据库，兼容MySQL和Oracle，支持分布式事务和实时分析'
    category: 'tech'
    tags: ['数据库']
    icon: 'icons/OceanBase.svg'
    sort: 1
    createdAt: '2026-03-20T08:30:35.101Z'

  - name: 'Redis'
    url: 'https://redis.io'
    description: '开源内存数据库，提供缓存、消息队列、向量检索和实时数据服务'
    category: 'tech'
    tags: ['数据库']
    icon: 'icons/Redis.svg'
    sort: 1
    createdAt: '2026-03-20T08:49:07.270Z'

  - name: '微信'
    url: 'https://weixin.qq.com'
    description: '微信官方网站，提供微信下载和功能介绍'
    category: 'social'
    tags: []
    icon: 'icons/微信.svg'
    sort: 1
    createdAt: '2026-03-29T02:35:09.724Z'

  - name: '华为商城'
    url: 'https://www.vmall.com'
    description: '华为官方电商平台，销售手机、电脑、智能设备等华为产品'
    category: 'shopping'
    tags: ['购物']
    icon: 'icons/华为商城.svg'
    sort: 1
    createdAt: '2026-03-29T03:46:10.556Z'

  - name: '高伟达工时系统'
    url: 'http://pm.git.com.cn'
    description: '高伟达公司内部工时管理系统'
    category: 'custom_1774756924959'
    tags: []
    icon: 'icons/高伟达邮箱.svg'
    sort: 1
    createdAt: '2026-03-29T04:04:38.374Z'

  - name: '8thManage'
    url: 'http://gain.git.com.cn'
    description: '高伟达公司内部项目管理系统'
    category: 'custom_1774756924959'
    tags: []
    icon: 'icons/高伟达邮箱.svg'
    sort: 1
    createdAt: '2026-03-29T04:08:08.344Z'

  - name: 'Tavily'
    url: 'https://auth.tavily.com'
    description: '面向AI智能体的实时网络搜索API，提供网页搜索、内容提取和研究分析服务'
    category: 'custom_1773890047269'
    tags: ['搜索引擎']
    icon: 'icons/Tavily.svg'
    sort: 1
    createdAt: '2026-03-29T04:33:46.620Z'

  - name: 'Core''s Bitcoin Staking'
    url: 'https://stake.coredao.org'
    description: 'Core区块链的比特币质押平台，可将BTC质押获取收益'
    category: 'web3'
    tags: []
    icon: 'icons/Cores_Bitcoin_Staking.svg'
    sort: 1
    createdAt: '2026-03-29T12:50:24.068Z'

  - name: 'XXL开源项目'
    url: 'https://www.xuxueli.com'
    description: 'XXL开源社区，提供分布式任务调度、服务管理等开源技术方案'
    category: 'tech'
    tags: ['工具']
    icon: 'icons/XXL开源项目.ico'
    sort: 1
    createdAt: '2026-03-29T13:02:37.615Z'

  - name: 'elastic'
    url: 'https://www.elastic.co/cn'
    description: 'Elasticsearch搜索和分析引擎，提供全文搜索、日志分析和可观测性服务'
    category: 'tech'
    tags: ['数据库']
    icon: 'icons/elastic.svg'
    sort: 1
    createdAt: '2026-03-29T13:07:08.594Z'

  - name: 'postgresql'
    url: 'https://jdbc.postgresql.org'
    description: 'PostgreSQL数据库的JDBC驱动官方文档和下载'
    category: 'tech'
    tags: ['数据库']
    icon: 'icons/postgresql.svg'
    sort: 1
    createdAt: '2026-03-29T13:52:40.517Z'

  - name: 'deepin'
    url: 'https://www.deepin.org/index/zh'
    description: '基于Linux的国产桌面操作系统，界面美观、开箱即用'
    category: 'tech'
    tags: ['操作系统']
    icon: 'icons/deepin.ico'
    sort: 1
    createdAt: '2026-03-29T13:59:05.855Z'

  - name: 'motrix'
    url: 'https://motrix.app/zh-CN'
    description: '一款全能的下载工具，支持下载 HTTP、FTP、BT、磁力链接等资源。'
    category: 'office'
    tags: ['下载']
    icon: 'icons/motrix.svg'
    sort: 1
    createdAt: '2026-03-29T14:04:57.250Z'

  - name: 'acpx'
    url: 'https://github.com/openclaw/acpx'
    description: 'Agent Client Protocol，通过stdio JSON-RPC协议让OpenClaw调用外部编码代理（Claude Code、Codex等）'
    category: 'custom_1791869874653'
    tags: ['源码']
    icon: 'icons/GitHub.svg'
    sort: 1
    createdAt: '2026-03-30T02:35:28.563Z'

  - name: 'GitCode'
    url: 'https://gitcode.com'
    description: 'CSDN与华为云联合开发的代码托管平台，支持AI驱动的开源协作研发'
    category: 'tech'
    tags: ['项目托管']
    icon: 'icons/GitCode.svg'
    sort: 1
    createdAt: '2026-03-31T03:13:06.497Z'

  - name: 'OpenSpec'
    url: 'https://github.com/Fission-AI/OpenSpec'
    description: '面向AI编码助手的规范驱动开发工具，通过结构化需求规范管理AI辅助开发流程'
    category: 'custom_1791869874653'
    tags: ['源码']
    icon: 'icons/GitHub.svg'
    sort: 1
    createdAt: '2026-04-02T03:24:44.093Z'

  - name: '网易云音乐'
    url: 'https://music.163.com'
    description: '网易旗下音乐流媒体平台，提供音乐播放、歌单管理和社区互动'
    category: 'video'
    tags: ['音乐']
    icon: 'icons/网易云音乐.svg'
    sort: 1
    createdAt: '2026-03-29T03:34:36.044Z'

  - name: '新一代零售信贷核算项目'
    url: 'http://localhost:8181/aplus_ote_ui/a/login'
    description: '新一代零售信贷核算项目'
    category: 'custom_1774756924959'
    tags: []
    icon: 'icons/高伟达邮箱.svg'
    sort: 1
    createdAt: '2026-08-22T00:00:51.377Z'

  - name: '淘宝'
    url: 'https://www.taobao.com'
    description: '购物网站'
    category: 'shopping'
    tags: ['购物']
    icon: 'icons/淘宝.svg'
    sort: 1
    createdAt: '2026-08-23T04:04:02.125Z'

  - name: 'iLovePDF'
    url: 'https://www.ilovepdf.com/'
    description: 'iLovePDF is an online service to work with PDF files completely free and easy to use. Merge PDF, split PDF, compress PDF, office to PDF, PDF to JPG and more!'
    category: 'office'
    tags: ['工具']
    icon: 'icons/iLovePDF.svg'
    sort: 1
    createdAt: '2026-09-14T14:54:04.315Z'

  - name: 'CocoLoop'
    url: 'https://www.cocoloop.cn/'
    description: 'CocoLoop - 专注AI智能体、OpenClaw、Molili的中文技术社区，涵盖部署教程、Skill开发、模型评测、效率工具等话题'
    category: 'custom_1773890047269'
    tags: ['技能']
    icon: ''
    sort: 1
    createdAt: '2026-09-20T11:48:55.509Z'

  - name: 'HowToLiveBetter'
    url: 'https://github.com/eternity4719/HowToLiveBetter'
    description: '高性价比人生指南:长寿防病、急救、省钱理财、法律红线、失业与工伤、医保社保、恋爱婚育、怀孕育儿、创业与做平台合规、出国与技能。每条写明成本、收益、证据等级和原始出处，只引期刊论文与官方文件。'
    category: 'custom_1791869874653'
    tags: []
    icon: 'icons/GitHub.svg'
    sort: 1
    createdAt: '2026-10-13T05:38:30.984Z'

  - name: 'm3e-canvas'
    url: 'https://github.com/lnkiai/m3e-canvas'
    description: 'M3E Canvas 是一个开源的浏览器端 UI 设计工具，核心目标是让用户通过拖拽方式快速搭建 Material 3 Expressive 风格的应用界面，并自动生成结构化的自然语言提示词，直接用于 AI 编程工具（如 Claude Code、Codex、Cursor 等）进行后续开发。 在线使用：直接访问 https://lnkiai.github.io/m3e-canvas/'
    category: 'custom_1791869874653'
    tags: []
    icon: 'icons/GitHub.svg'
    sort: 1
    createdAt: '2026-10-13T05:59:40.403Z'

  - name: 'QtScrcpy'
    url: 'https://github.com/barry-ran/QtScrcpy'
    description: '喜欢 不喜欢 QtScrcpy 是一款基于 Scrcpy 内核开发的免费开源 Android 投屏与控制工具，支持 USB/WiFi 连接、低延迟高清投屏，并提供完整图形界面，适用于 Windows、macOS 与 Linux。'
    category: 'custom_1791869874653'
    tags: []
    icon: 'icons/GitHub.svg'
    sort: 1
    createdAt: '2026-10-13T06:59:59.977Z'

  - name: '号码生成器'
    url: '/games/id-generator/index.html'
    description: '身份证、手机号等号码生成工具'
    category: 'office'
    tags: ['游戏', '工具']
    icon: '/icons/haoma.svg'
    sort: 1
    createdAt: '2026-10-01T16:35:49.975Z'

  - name: '中华人民共和国人力资源和社会资金保障部'
    url: 'https://www.mohrss.gov.cn/'
    description: 'https://www.mohrss.gov.cn/SYrlzyhshbzb/laodongguanxi_/fwyd/ 最低工资标准'
    category: 'custom_1790770591238'
    tags: []
    icon: 'icons/中华人民共和国人力资源和社会资金保障部.svg'
    sort: 1
    createdAt: '2026-10-22T01:27:02.379Z'

  - name: '工具箱'
    url: '/toolbox'
    description: '站内工具箱：各类在线小工具集合'
    category: 'other'
    tags: ['站内模块']
    icon: 'icons/工具箱.svg'
    sort: 0
    createdAt: '2026-10-26T00:00:00.000Z'

  - name: '我的博客'
    url: '/blog'
    description: '站内博客阅读页：浏览已发布的文章'
    category: 'other'
    tags: ['站内模块']
    icon: 'icons/我的博客.svg'
    sort: 0
    createdAt: '2026-10-26T00:00:00.000Z'

  - name: '我的图书'
    url: '/books'
    description: '站内个人图书馆：书架检索与站内阅读'
    category: 'other'
    tags: ['站内模块']
    icon: 'icons/我的图书.svg'
    sort: 0
    createdAt: '2026-10-26T00:00:00.000Z'
---

# 我的书签

个人常用的网站导航
